# Linux Task 01 — Secure File Management & User Configuration on Kali Linux

## Project Description

This repository is a GitHub-ready practical-lab guide for **Practical Task: Secure File Management & User Configuration on Kali Linux**.

The activity demonstrates fundamental Linux file-system and user-management commands by creating a new user, building a workspace, creating and managing files, handling permissions, simulating an error, and observing the effect of changing file ownership.

> **Important:** This repository is a workflow/template. It does not contain fabricated command output, screenshots, permissions, or completed results. Perform the commands in your Kali Linux lab and save your own evidence.

## Objective

Demonstrate understanding of fundamental Linux file-system and user-management commands by setting up a secure workspace for a newly created user and organizing files with proper permissions and structure.

## Lab Requirements

According to the task:

- Create a user named `agent007`.
- Give the user a home directory and `/bin/bash` as the shell.
- Add `agent007` to the `sudo` group.
- Set a password for `agent007`.
- Perform all file operations using `agent007`, not root.
- The exceptions are `useradd` and `usermod`/user-account configuration operations required by the task.
- Create the required `mission/intel` and `mission/ops/backup` structure.
- Create `targets.txt`, `routes.txt`, and `keys.txt`.
- Capture the outputs of `ls`, `ls -l`, and `ls -la` into separate files.
- Copy and remove files as instructed.
- Configure the required permissions on `targets.txt`.
- Intentionally remove and then restore `routes.txt` in `backup/`.
- As root, change ownership of `intel/targets.txt` to another user (the task gives `root` as an example).
- Submit command history, final recursive listing, and a 4–5 line explanation of `chmod`, `ls -l`, and `useradd`.

The exact source task is preserved in `docs/task-overview.md`. fileciteturn0file0L2-L10

## Technologies / Tools

- Kali Linux
- Bash
- Linux user-management commands
- Linux file and directory commands
- `mkdir`
- `cd`
- `touch`
- `ls`
- shell output redirection (`>`)
- `cp`
- `rm`
- `chmod`
- `chown`
- `sudo`
- `useradd`
- `passwd`
- `su`

## Prerequisites

- A working Kali Linux environment.
- Administrative/sudo access sufficient to create `agent007` and perform the ownership-change step.
- A terminal.
- The ability to capture screenshots and save command history.

## Environment / Permission Rules

**Critical task rule:** Do not use the root account to perform the file operations. The task explicitly requires the remaining steps to be performed through `agent007`. fileciteturn0file0L9-L10

Use:

- **Administrative privileges:** user creation/account configuration and the final ownership change.
- **`agent007`:** workspace creation, file creation/listing, copying, deletion, permission changes, error/recovery activity, and verification unless the task explicitly requires root.

Do not replace the task's permission model with a different workflow.

## Project Structure

```text
linux-task-01-secure-file-management/
├── README.md
├── .gitignore
├── docs/
│   ├── README.md
│   └── task-overview.md
├── workflow/
│   ├── README.md
│   └── workflow.md
├── commands/
│   ├── README.md
│   └── commands.sh
├── scripts/
│   └── README.md
├── evidence/
│   ├── README.md
│   ├── screenshots/
│   │   └── .gitkeep
│   └── terminal-output/
│       └── .gitkeep
└── submission/
    ├── README.md
    ├── command-history.txt
    └── final-output.txt
```

## Practical Workflow

1. Create `agent007` and configure the requested shell, home directory, and sudo group.
2. Set the password and switch to `agent007`.
3. Create the `mission/intel` and `mission/ops/backup` workspace.
4. Create the three required empty files.
5. Capture `ls`, `ls -l`, and `ls -la` outputs into the required listing files.
6. Copy `routes.txt` into `backup/`.
7. Remove `keys.txt` from `intel/`.
8. Set `targets.txt` permissions to owner read/write, group read-only, others no permissions.
9. Intentionally remove the backup copy of `routes.txt`, then restore it from `intel/`.
10. As root, change ownership of `targets.txt` to another user (for example, `root`), then return to `agent007` and inspect it with `ls -l`.
11. Run the final recursive listing required for submission.
12. Save command history and prepare the required explanation.

The core workspace and file requirements are stated in the source task. fileciteturn0file0L20-L46

## Expected Results

The task specifies these final-state expectations:

- `agent007` exists with a home directory and Bash shell.
- `agent007` belongs to the `sudo` group.
- `/home/agent007/mission/` exists with `intel/` and `ops/backup/`.
- `routes.txt` is present in `intel/` and restored to `ops/backup/`.
- `keys.txt` has been removed from `intel/`.
- `targets.txt` has owner read/write, group read-only, and no permissions for others before the ownership-change observation.
- The listing files exist in `intel/` and contain the corresponding `ls`, `ls -l`, and `ls -la` outputs.
- The final recursive listing is produced for submission.
- The ownership-change step has been performed as root and observed again as `agent007`.

Do not assume exact ownership/group output or timestamps until you run the commands yourself.

## Evidence Requirements

The source task explicitly requires:

1. Command history (`.bash_history` or a copy/paste of commands used).
2. A screenshot or text file showing:
   `ls -laR /home/agent007/mission/`
3. A 4–5 line explanation of:
   - `chmod`
   - `ls -l`
   - `useradd`

Additional screenshots in `evidence/screenshots/` are organized as recommended evidence for the practical steps; they are not additional requirements invented as submission requirements. fileciteturn0file0L50-L54

## Safety / Permission Notes

This is a local Linux administration exercise. Keep the activity inside your authorized Kali Linux lab environment.

The ownership-change step intentionally changes the ownership of `intel/targets.txt`. Follow the task's instruction carefully and observe the resulting permissions/ownership rather than trying to work around them.

## Troubleshooting

### `useradd: user 'agent007' already exists`

Check the account before making changes:

```bash
id agent007
getent passwd agent007
```

If this is a fresh lab and the account was created during an earlier attempt, continue only if its configuration matches the task. Do not delete or recreate accounts blindly.

### Permission denied while creating files

Check the current identity:

```bash
whoami
pwd
```

The file operations should be performed as `agent007`, not root.

### `sudo` does not work for `agent007`

Verify group membership:

```bash
id agent007
groups agent007
```

A newly added sudo-group membership may require starting a new login/session before it is reflected.

### The final ownership change prevents modification

That is expected to be observable after `chown`. Inspect the file:

```bash
ls -l /home/agent007/mission/intel/targets.txt
```

Do not fabricate or alter the result; record what your lab actually shows.

## Final Verification Checklist

- [ ] `agent007` created.
- [ ] Home directory created.
- [ ] `/bin/bash` configured as the shell.
- [ ] `agent007` added to the `sudo` group.
- [ ] Password set for `agent007`.
- [ ] Switched to `agent007` before file operations.
- [ ] `mission/intel` created.
- [ ] `mission/ops/backup` created.
- [ ] `targets.txt`, `routes.txt`, and `keys.txt` created.
- [ ] `ls` output saved to `listing1.txt`.
- [ ] `ls -l` output saved to `listing2.txt`.
- [ ] `ls -la` output saved to `listing3.txt`.
- [ ] `routes.txt` copied to `backup/`.
- [ ] `keys.txt` removed.
- [ ] `targets.txt` permissions configured as required.
- [ ] `targets.txt` permissions verified with `ls -l`.
- [ ] Backup `routes.txt` intentionally removed.
- [ ] Backup `routes.txt` restored from `intel/`.
- [ ] Ownership of `targets.txt` changed as root.
- [ ] Ownership result observed as `agent007`.
- [ ] Final `ls -laR /home/agent007/mission/` output captured.
- [ ] Command history captured.
- [ ] 4–5 line explanation completed.
- [ ] Evidence reviewed before submission.

## Source Task

The complete task-derived overview is in [`docs/task-overview.md`](docs/task-overview.md).

The detailed practical procedure is in [`workflow/workflow.md`](workflow/workflow.md).

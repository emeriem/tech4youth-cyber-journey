# Scripts

No executable automation scripts are included for this activity.

This is intentional: the practical is designed to teach Linux user management, file operations, permissions, error recovery, and ownership. Automating the entire exercise would hide important learning and verification steps.

Use `commands/commands.sh` as a commented reference sequence instead.

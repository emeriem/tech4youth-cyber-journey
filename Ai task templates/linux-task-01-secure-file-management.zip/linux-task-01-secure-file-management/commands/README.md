# Commands

`commands.sh` is a reference command sequence for the practical task.

It is intentionally not a fully automatic setup script. The activity is designed as a learning exercise and contains account switching, password entry, deliberate deletion/recovery, and an ownership change that should be observed manually.

Read the comments and execute commands one section at a time.

#!/usr/bin/env bash
# Linux Task 01 — Secure File Management & User Configuration
# Reference command sequence — NOT an unattended automation script.
#
# IMPORTANT:
# - Run account-creation commands from an administrative/sudo-capable account.
# - Run file operations as agent007, not root.
# - Password entry is intentionally manual.
# - The ownership change is intentionally manual and requires root.
# - Review each command before executing it.

# ============================================================
# PHASE 1 — CREATE USER
# Execution identity: existing sudo-capable account
# ============================================================

sudo useradd -m -s /bin/bash -G sudo agent007

# Verify account configuration.
id agent007
getent passwd agent007

# ============================================================
# PHASE 2 — PASSWORD + SWITCH USER
# ============================================================

# Manual interactive password operation:
sudo passwd agent007

# Manual interactive account switch:
su - agent007

# Verify identity.
whoami
pwd

# ============================================================
# PHASE 3 — WORKSPACE
# Execution identity: agent007
# ============================================================

cd /home/agent007
mkdir -p mission/intel mission/ops/backup
cd mission

# Verify workspace.
ls -la
ls -la intel
ls -la ops/backup

# ============================================================
# PHASE 4 — FILE CREATION
# Execution identity: agent007
# ============================================================

cd /home/agent007/mission/intel
touch targets.txt routes.txt keys.txt

ls -la

# ============================================================
# PHASE 5 — REQUIRED LISTING OUTPUTS
# ============================================================

ls > listing1.txt
ls -l > listing2.txt
ls -la > listing3.txt

# Verify captured output.
cat listing1.txt
cat listing2.txt
cat listing3.txt

# ============================================================
# PHASE 6 — COPY + REMOVE
# ============================================================

cp routes.txt /home/agent007/mission/ops/backup/
ls -la /home/agent007/mission/ops/backup/

rm keys.txt
ls -la /home/agent007/mission/intel/

# ============================================================
# PHASE 7 — PERMISSIONS
# Required: owner rw, group r, others ---
# ============================================================

chmod 640 targets.txt
ls -l targets.txt

# ============================================================
# PHASE 8 — ERROR SIMULATION + RECOVERY
# ============================================================

rm /home/agent007/mission/ops/backup/routes.txt
ls -la /home/agent007/mission/ops/backup/

cp /home/agent007/mission/intel/routes.txt /home/agent007/mission/ops/backup/
ls -la /home/agent007/mission/ops/backup/

# ============================================================
# PHASE 9 — OWNERSHIP CHANGE
# Execution identity: ROOT
#
# Do NOT run this as agent007. Switch to root/admin context first.
# ============================================================

# Example manual root operation:
# chown root /home/agent007/mission/intel/targets.txt
# ls -l /home/agent007/mission/intel/targets.txt

# Then switch back to agent007 and observe:
# ls -l /home/agent007/mission/intel/targets.txt

# ============================================================
# PHASE 10 — SUBMISSION EVIDENCE
# Execution identity: agent007
# ============================================================

# Run and capture the exact required final output:
ls -laR /home/agent007/mission/

# To save it as a text file from the directory containing
# the repository's submission/ folder, use:
# ls -laR /home/agent007/mission/ > submission/final-output.txt

# Capture command history using the task-approved method:
history
# or:
# cat ~/.bash_history

# Evidence

This directory is for **real evidence produced while performing the lab**.

Do not create fake screenshots or fabricated output.

## Required Submission Evidence

The uploaded task explicitly requires:

1. Command history (`.bash_history` or a copy-paste of commands used).
2. A screenshot or text file showing:
   `ls -laR /home/agent007/mission/`
3. A 4–5 line explanation of `chmod`, `ls -l`, and `useradd`.

## Recommended Screenshot Sequence

The following filenames are suggested to keep evidence organized. These are documentation aids, not additional formal submission requirements.

| Filename | What it should prove |
|---|---|
| `01-agent007-created.png` | `agent007` account exists with the requested configuration |
| `02-agent007-session.png` | The terminal is operating as `agent007` |
| `03-workspace-created.png` | `mission/intel` and `mission/ops/backup` exist |
| `04-files-created.png` | Required files were created in `intel` |
| `05-listing-outputs.png` | Required listing commands/output are present |
| `06-copy-remove.png` | `routes.txt` backup and `keys.txt` removal |
| `07-targets-permissions.png` | Required `targets.txt` permission state |
| `08-error-recovery.png` | Backup removal and restoration |
| `09-ownership-change.png` | Ownership change and subsequent `ls -l` observation |
| `10-final-recursive-listing.png` | Final `ls -laR /home/agent007/mission/` output |

## Terminal Output

Use `evidence/terminal-output/` for text evidence where useful.

The actual final recursive output may also be retained in `submission/final-output.txt`, as required by the task.

## Evidence Quality

A useful screenshot should show:

- the command that was run;
- the relevant output;
- enough terminal context to identify the operation;
- no passwords or other sensitive information.

Do not edit command output to make it look successful. If an error occurs during the intended error simulation, preserve the real behavior and document what happened.

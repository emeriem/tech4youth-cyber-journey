# Complete Practical Workflow

> **Rule:** File operations must be performed as `agent007`, not root. Administrative privileges are used only where the task requires account configuration or the final ownership change.

---

## Phase 1 — Create the Required User

### Step 1. Create `agent007`

**Execution identity:** existing administrative/sudo-capable account.

```bash
sudo useradd -m -s /bin/bash -G sudo agent007
```

**Purpose:** Creates `agent007`, creates the home directory, sets `/bin/bash` as the login shell, and adds the account to the `sudo` group.

**Expected result:** The command completes without an error.

**Verification:**

```bash
id agent007
getent passwd agent007
```

Confirm that the account exists, has the expected home directory, shell, and group membership.

**Evidence:** Capture the verification output if you want a clear record of account configuration.

---

## Phase 2 — Set the Password and Switch Accounts

### Step 2. Set the password

**Execution identity:** administrative/sudo-capable account.

```bash
sudo passwd agent007
```

Enter and confirm a password when prompted.

**Expected result:** The password is accepted and the account can authenticate.

**Evidence:** Do not capture or expose the password itself.

### Step 3. Switch to `agent007`

```bash
su - agent007
```

**Execution identity:** use the terminal to switch into the new account.

**Verification:**

```bash
whoami
pwd
```

**Expected result:** `whoami` reports `agent007`, and `pwd` should place you in the user's home directory.

**Evidence:** Capture a screenshot showing the account/session state if useful.

---

## Phase 3 — Build the Workspace

### Step 4. Create the directory structure

**Execution identity:** `agent007`

```bash
cd /home/agent007
mkdir -p mission/intel mission/ops/backup
cd mission
```

**Purpose:** Creates the required `mission/intel` and `mission/ops/backup` directories.

**Verification:**

```bash
ls -la
ls -la intel
ls -la ops/backup
```

**Expected result:** Both required branches of the workspace exist.

**Evidence:** A screenshot of the directory listing can document the structure.

---

## Phase 4 — Create the Required Files

### Step 5. Create the three empty files

**Execution identity:** `agent007`

```bash
cd /home/agent007/mission/intel
touch targets.txt routes.txt keys.txt
```

**Purpose:** Creates the three empty files required by the task.

**Verification:**

```bash
ls -la
```

**Expected result:** `targets.txt`, `routes.txt`, and `keys.txt` are present.

**Evidence:** Capture the listing if documenting this phase.

---

## Phase 5 — Capture the Three Required Listings

### Step 6. Save `ls` output

**Execution identity:** `agent007`

```bash
ls > listing1.txt
```

**Purpose:** Saves the normal directory listing into `listing1.txt`.

**Verification:**

```bash
cat listing1.txt
```

**Evidence:** Capture the command and output if needed.

### Step 7. Save `ls -l` output

```bash
ls -l > listing2.txt
```

**Purpose:** Saves the long-format listing, including permissions and ownership metadata, into `listing2.txt`.

**Verification:**

```bash
cat listing2.txt
```

### Step 8. Save `ls -la` output

```bash
ls -la > listing3.txt
```

**Purpose:** Saves the long-format listing including hidden entries into `listing3.txt`.

**Verification:**

```bash
cat listing3.txt
```

**Important:** Because each listing file is created by the redirection itself, later listings may include files created by earlier steps. This is normal shell behavior. Do not manually fabricate or edit the captured output.

---

## Phase 6 — Copy and Remove Files

### Step 9. Copy `routes.txt` into `backup`

**Execution identity:** `agent007`

```bash
cp routes.txt /home/agent007/mission/ops/backup/
```

**Purpose:** Creates the backup copy required by the task.

**Verification:**

```bash
ls -la /home/agent007/mission/ops/backup/
```

**Expected result:** `routes.txt` is present in `backup/`.

### Step 10. Remove `keys.txt`

```bash
rm keys.txt
```

**Purpose:** Deletes `keys.txt` from `intel/` as required.

**Verification:**

```bash
ls -la /home/agent007/mission/intel/
```

**Expected result:** `keys.txt` is no longer listed.

**Evidence:** Capture a screenshot if documenting the removal.

---

## Phase 7 — Configure `targets.txt` Permissions

### Step 11. Apply the required permissions

**Execution identity:** `agent007`

The required permission state is:

- owner = read + write
- group = read only
- others = no permissions

Use:

```bash
chmod 640 targets.txt
```

**Purpose:** Sets the permission bits to owner `rw`, group `r`, others `---`.

**Verification:**

```bash
ls -l targets.txt
```

**Expected permission pattern:** `-rw-r-----` (the exact owner/group names and timestamps depend on the lab).

**Evidence:** Capture the `chmod` command and `ls -l` result.

---

## Phase 8 — Simulate the Error and Recover

### Step 12. Intentionally remove the backup copy

**Execution identity:** `agent007`

```bash
rm /home/agent007/mission/ops/backup/routes.txt
```

**Purpose:** Intentionally creates the missing-backup condition required by the task.

**Verification:**

```bash
ls -la /home/agent007/mission/ops/backup/
```

**Expected result:** `routes.txt` is absent from `backup/`.

### Step 13. Restore the file

```bash
cp /home/agent007/mission/intel/routes.txt /home/agent007/mission/ops/backup/
```

**Purpose:** Restores the deleted backup copy from `intel/`.

**Verification:**

```bash
ls -la /home/agent007/mission/ops/backup/
```

**Expected result:** `routes.txt` is present again.

**Evidence:** A screenshot showing the final backup listing is useful evidence of recovery.

---

## Phase 9 — Change Ownership as Root

### Step 14. Change ownership of `targets.txt`

The task specifically requires the ownership change to be performed **as root** and gives `root` as an example of another user.

First leave the `agent007` session or open an administrative terminal according to your lab setup. Then run as root:

```bash
chown root /home/agent007/mission/intel/targets.txt
```

If your lab requires switching to root explicitly:

```bash
su -
```

Then run the `chown` command above.

**Purpose:** Changes the owner of `targets.txt` to `root`.

**Verification as root:**

```bash
ls -l /home/agent007/mission/intel/targets.txt
```

Then switch back to `agent007` and run the same verification:

```bash
ls -l /home/agent007/mission/intel/targets.txt
```

**Expected result:** The owner field now reflects the user selected for the ownership-change step.

**Evidence:** Capture the `ls -l` result after returning to `agent007`.

**Important:** Do not claim a specific group, timestamp, or exact output until your system produces it.

---

## Phase 10 — Final Submission Evidence

### Step 15. Generate the required final recursive listing

**Execution identity:** `agent007` unless your environment prevents access to the required listing.

```bash
ls -laR /home/agent007/mission/
```

Save the output to the submission file:

```bash
ls -laR /home/agent007/mission/ > submission/final-output.txt
```

> If you are currently inside `/home/agent007/mission/`, the relative `submission/final-output.txt` path works. Otherwise use the absolute path to the repository's submission directory.

**Purpose:** The task explicitly requires a screenshot or text file showing this final recursive listing.

**Evidence:** Keep the actual output in `submission/final-output.txt` and/or capture a screenshot in `evidence/screenshots/`.

### Step 16. Capture command history

Use one of the task-approved approaches:

```bash
history
```

or inspect:

```bash
cat ~/.bash_history
```

Copy the relevant command history into:

```text
submission/command-history.txt
```

Do not include passwords or other sensitive information.

### Step 17. Complete the 4–5 line explanation

Write a concise explanation covering:

- `chmod`
- `ls -l`
- `useradd`

Use `submission/README.md` as the submission guide and place your final explanation in the designated submission material.

---

# Final Verification Checklist

- [ ] `agent007` exists.
- [ ] `agent007` has a home directory.
- [ ] `agent007` uses `/bin/bash`.
- [ ] `agent007` is in the `sudo` group.
- [ ] Password has been set.
- [ ] File operations were performed as `agent007`.
- [ ] `/home/agent007/mission/intel/` exists.
- [ ] `/home/agent007/mission/ops/backup/` exists.
- [ ] `targets.txt` exists.
- [ ] `routes.txt` exists in `intel/`.
- [ ] `keys.txt` was created and then removed.
- [ ] `listing1.txt` contains the `ls` output.
- [ ] `listing2.txt` contains the `ls -l` output.
- [ ] `listing3.txt` contains the `ls -la` output.
- [ ] `routes.txt` was copied into `backup/`.
- [ ] `targets.txt` was set to owner `rw`, group `r`, others `---`.
- [ ] `targets.txt` permissions were verified with `ls -l`.
- [ ] The backup `routes.txt` was intentionally removed.
- [ ] The backup `routes.txt` was restored.
- [ ] Ownership of `targets.txt` was changed as root.
- [ ] The ownership result was observed as `agent007`.
- [ ] Final `ls -laR /home/agent007/mission/` output captured.
- [ ] Command history captured.
- [ ] 4–5 line explanation completed.

# Workflow

See [`workflow.md`](workflow.md) for the complete step-by-step practical procedure.

The workflow identifies the required execution identity, command, purpose, expected result, verification, and evidence for each major step.

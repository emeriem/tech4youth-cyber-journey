# Task Overview — Linux Task 01

## Source Task

**Practical Task:** Secure File Management & User Configuration on Kali Linux

## Objective

Demonstrate understanding of fundamental Linux file-system and user-management commands by setting up a secure workspace for a newly created user and organizing files with proper permissions and structure. fileciteturn0file0L2-L7

## Important Restriction

The task says not to use the root user for file operations. A new user must be created, and all steps except `useradd` and `usermod` must be performed using that user's account. fileciteturn0file0L8-L10

## Required Task Steps

### 1. Create a New User

Create:

- Username: `agent007`
- Home directory: required
- Shell: `/bin/bash`
- Group membership: `sudo`

Required command given by the task:

```bash
sudo useradd -m -s /bin/bash -G sudo agent007
```

### 2. Switch to the New User

- Set a password for `agent007`.
- Switch to `agent007`.
- Perform the rest of the activity using this account. fileciteturn0file0L17-L19

### 3. Setup Workspace

Inside `/home/agent007/`, create:

```text
mission/
├── intel/
└── ops/
    └── backup/
```

Use `mkdir` and `cd` as instructed. fileciteturn0file0L20-L27

### 4. File Creation and Listing

Inside `intel/`, create:

```text
targets.txt
routes.txt
keys.txt
```

Then use:

- `ls`
- `ls -l`
- `ls -la`

Redirect each listing into:

```text
listing1.txt
listing2.txt
listing3.txt
```

respectively, inside `intel/`. fileciteturn0file0L28-L33

### 5. Copy and Remove Files

- Copy `routes.txt` to `ops/backup/`.
- Delete `keys.txt` from `intel/` using `rm`. fileciteturn0file0L34-L36

### 6. Permissions Handling

Change `targets.txt` so that:

- Owner: read + write
- Group: read only
- Others: no permissions

Use `chmod` and verify with `ls -l`. fileciteturn0file0L37-L42

### 7. Simulate an Error and Recover

- Intentionally remove `ops/backup/routes.txt`.
- Copy `routes.txt` from `intel/` back into `backup/`.
- This tests `cp` and basic error recovery. fileciteturn0file0L43-L46

### 8. Advanced Permissions & Ownership

As root:

- Change ownership of `intel/targets.txt` to another user, with `root` given as an example.
- Switch back to `agent007`.
- Observe the result using `ls -l`. fileciteturn0file0L47-L49

## Submission Requirements

The task requires:

- Command history (`.bash_history` or a copy-paste of commands used).
- Screenshot or text file showing the final:
  `ls -laR /home/agent007/mission/`
- 4–5 line explanation of what `chmod`, `ls -l`, and `useradd` do. fileciteturn0file0L50-L54

## Requirements Not Added

This project does not treat the recommended screenshots, extra verification commands, or troubleshooting suggestions as formal task submission requirements. They are included only to make the workflow easier to perform and document.

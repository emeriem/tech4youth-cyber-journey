# Documentation

This directory contains the task-derived documentation.

- `task-overview.md` — faithful extraction and interpretation of the uploaded practical task.

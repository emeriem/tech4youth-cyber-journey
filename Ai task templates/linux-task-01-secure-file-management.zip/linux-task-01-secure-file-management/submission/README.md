# Submission Guide

## Required Submission Items

The task requires three categories of submission material:

### 1. Command History

Submit either:

- `.bash_history`, or
- a copy/paste of the commands used.

Use `submission/command-history.txt` for the copy/paste option.

Template:

```text
[PASTE THE ACTUAL COMMAND HISTORY USED FOR THIS LAB HERE]
```

Do not include passwords.

### 2. Final Recursive Listing

The task requires a screenshot or text file showing:

```bash
ls -laR /home/agent007/mission/
```

Use `submission/final-output.txt` to store the actual output.

Template:

```text
[PASTE THE ACTUAL ls -laR /home/agent007/mission/ OUTPUT HERE]
```

A screenshot of the same output can be stored in `evidence/screenshots/`.

### 3. 4–5 Line Explanation

Provide a 4–5 line explanation of what these commands do:

- `chmod`
- `ls -l`
- `useradd`

Suggested template to complete in your own words:

```text
chmod: [YOUR 1-line explanation]

ls -l: [YOUR 1-line explanation]

useradd: [YOUR 1-line explanation]

[OPTIONAL 1 additional line connecting these commands to the task.]
```

## Before Submission

- [ ] Command history is real and comes from the lab.
- [ ] No password is included.
- [ ] Final recursive listing is real.
- [ ] Explanation is 4–5 lines.
- [ ] Required screenshots/text evidence are included.
- [ ] No fabricated output or screenshots are present.
